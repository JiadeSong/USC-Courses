

Files whose names have the form 
*legit*.txt are legitimate messages. The first number in each filename
is random; it was used to shuffle the messages. The second number was
the initial identifier of the message; it does not reflect the order 
in which the messages were received. To bypass privacy issues, the 
messages are "encoded". 

